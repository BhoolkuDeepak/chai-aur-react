function ChildComponent({onButtonClick}){
    return (
        <>
     
        <button onClick = {onButtonClick}>Child Component</button></>
    )
}

export default ChildComponent