import { Component } from "react"


class Greetings extends Component{
    render(){
        return <p>Hello World || Class Component</p>
    }
}
export default Greetings