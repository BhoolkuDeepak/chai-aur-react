

function Greeting(){
    return (
        <p>Hello World || Function Component</p>
    )
}

export default Greeting
